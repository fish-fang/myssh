package org.login.common;

public enum AuthorityLevel {
	LEVEL1,LEVEL2,LEVEL3,LEVEL4
}
