package org.login.common;

public class NoAccessException extends Exception {
	private static final long serialVersionUID = 1L;
}
