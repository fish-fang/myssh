package org.login.common;

public enum OperateType {
	SELECT,ADD,UPDATE,DELETE,ANYTHING_ELSE
}
