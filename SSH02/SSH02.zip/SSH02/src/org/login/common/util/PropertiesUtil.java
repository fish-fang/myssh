package org.login.common.util;

import java.util.Properties;

public class PropertiesUtil {
	public static Properties URL_PRO = null; 
}
